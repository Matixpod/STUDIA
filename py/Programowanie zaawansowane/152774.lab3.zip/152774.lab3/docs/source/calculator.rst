calculator module
=================

.. automodule:: calculator
   :members:
   :show-inheritance:
   :undoc-members:
