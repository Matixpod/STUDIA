.. Kalkulator klasowy documentation master file, created by
   sphinx-quickstart on Tue May  6 10:35:29 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Kalkulator klasowy documentation
================================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.



.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules
   README

Screenshot
==========

Poniżej znajduje się zrzut dokumentacji:

.. image:: img_html.jpg
   :alt: Zrzut ekranu index.html
   :align: center
   :width: 600px