# Kalkulator klasowy
Kalkulator wykonuje proste operacje matematyczne takie jak:
- dodawanie
- odejmowanie 
- mnożenie
- dzielenie

```python
def add(self, a, b):
        self.result = a + b
        return self.result
```
[Python Documentation](docs.python.org)

![Static Badge](https://img.shields.io/badge/python%203.13.2%20-%20green) ![Static Badge](https://img.shields.io/badge/%20Doctest-%20blue)


